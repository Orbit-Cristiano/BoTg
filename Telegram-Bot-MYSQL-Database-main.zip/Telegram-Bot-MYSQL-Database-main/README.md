# Telegram Bot with MySQL Database

This project is a Telegram bot that is connected to a MySQL database. The bot allows users to perform various actions on the database, such as inserting, updating, and retrieving data.

APP_ID and API_HASH for telethon: https://my.telegram.org/auth

BOT_TOKEN: Write on telegram to @BotFather and follow the instruction
